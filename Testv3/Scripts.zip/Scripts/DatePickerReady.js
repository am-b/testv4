﻿$(function () {
    $(".datefield").datepicker();
});