﻿$('#timepicker').timepicker({
    showPeriod: true,
    showLeadingZero: true
});