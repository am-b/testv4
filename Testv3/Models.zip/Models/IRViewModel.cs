﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Testv3.Models
{
    [Serializable]
    public class IRViewModel
    {
        
        public string name { get; set; }
    }
}